function show(){
    if(document.getElementById('para2').style.display = "none"){
        document.getElementById('para2').style.display = "block";
        document.getElementById('para3').innerHTML ="SHOW LESS";
    }
    else{
        document.getElementById('para2').style.display = "none";
        document.getElementById('para3').innerHTML ="SHOW ALL";
    }
}
function Enroll(){
    var t1 = document.getElementById('t1').value;
    var t2 = document.getElementById('t2').value;
    var t3 = document.getElementById('t3').value;
    var t4 = document.getElementById('t4').value;
    if(t1 == "" || t2 == "" || t3 == "" || t4 == "")
    {
        alert("plesase fill all fields");
    }
    else if(t3 != t4){
        alert("password/repassword is invalid");
    }
    else{
        alert("would you like to choose options");
    }
}
